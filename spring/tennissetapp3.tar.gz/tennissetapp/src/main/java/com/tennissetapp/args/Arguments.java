package com.tennissetapp.args;

public interface Arguments {

}
