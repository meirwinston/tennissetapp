package com.tennissetapp.args;

public class ScrollArgs implements Arguments{
	public long firstResult;
	public int maxResults;
}
