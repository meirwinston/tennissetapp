package com.tennissetapp.service;

import com.tennissetapp.forms.SignupForm;
import com.tennissetapp.persistence.entities.UserAccount;

public interface TestService {
	String test(String param);
//	UserAccount newUserAccount(SignupForm signupForm);
}
