package com.tennissetapp.persistence.entities;

@Deprecated
public class UserMateSelect {
	protected Float levelOfPlay;
	protected String firstName;
	protected String lastName;
	protected String country;
	protected String administrativeAreaLevel1;
	
}
