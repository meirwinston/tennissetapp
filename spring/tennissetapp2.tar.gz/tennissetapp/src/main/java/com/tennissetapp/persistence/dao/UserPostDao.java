package com.tennissetapp.persistence.dao;

import com.tennissetapp.forms.SubmitPostForm;
import com.tennissetapp.persistence.entities.UserPost;

@Deprecated
public interface UserPostDao {
//	UserPost create(SubmitPostForm form);
}
