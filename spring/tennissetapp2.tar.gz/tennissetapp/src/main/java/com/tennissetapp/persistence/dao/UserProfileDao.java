package com.tennissetapp.persistence.dao;

public class UserProfileDao {

}
